# CompuTrade

CompuTrade is a library designed for trading algorithms