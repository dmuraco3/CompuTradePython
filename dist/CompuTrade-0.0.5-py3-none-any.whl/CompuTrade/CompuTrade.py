def BuildAlgorithm():
    print("building algorithm")